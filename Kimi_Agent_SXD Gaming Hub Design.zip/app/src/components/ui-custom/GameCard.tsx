import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, ExternalLink } from 'lucide-react';
import type { Game } from '@/types';

interface GameCardProps {
  game: Game;
  index?: number;
}

export function GameCard({ game, index = 0 }: GameCardProps) {
  const isFree = game.price === 'Free';
  const hasDiscount = game.originalPrice && game.price !== 'Free';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ 
        duration: 0.5, 
        delay: index * 0.1,
        ease: [0.22, 1, 0.36, 1]
      }}
    >
      <Link to={`/game/${game.id}`}>
        <motion.div
          whileHover={{ y: -8, scale: 1.02 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          className="group relative bg-[#111318] rounded-xl overflow-hidden border border-white/5 
                     hover:border-cyan-400/30 transition-all duration-500"
        >
          {/* Image Container */}
          <div className="relative aspect-[3/4] overflow-hidden">
            <motion.img
              src={game.image}
              alt={game.title}
              className="w-full h-full object-cover"
              whileHover={{ scale: 1.08 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            />
            
            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-transparent to-transparent opacity-80" />
            
            {/* Category Badge */}
            <div className="absolute top-3 left-3">
              <span className="px-2.5 py-1 bg-black/60 backdrop-blur-sm rounded-md text-[10px] font-medium 
                             text-cyan-400 uppercase tracking-wider border border-cyan-400/20">
                {game.category}
              </span>
            </div>

            {/* Hover Overlay */}
            <div className="absolute inset-0 bg-cyan-400/10 opacity-0 group-hover:opacity-100 
                          transition-opacity duration-300 flex items-center justify-center">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                whileHover={{ scale: 1, opacity: 1 }}
                className="w-12 h-12 rounded-full bg-cyan-400 flex items-center justify-center"
              >
                <ExternalLink className="w-5 h-5 text-black" />
              </motion.div>
            </div>
          </div>

          {/* Content */}
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="text-lg font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors">
              {game.title}
            </h3>
            
            <p className="text-xs text-white/50 line-clamp-2 mb-3">
              {game.description}
            </p>

            <div className="flex items-center justify-between">
              {/* Rating */}
              {game.rating && game.rating > 0 && (
                <div className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
                  <span className="text-xs font-medium text-white/70">{game.rating}</span>
                </div>
              )}

              {/* Price */}
              <div className="flex items-center gap-2">
                {hasDiscount && (
                  <span className="text-xs text-white/40 line-through">
                    ${game.originalPrice}
                  </span>
                )}
                <span className={`text-sm font-bold ${isFree ? 'text-green-400' : 'text-cyan-400'}`}>
                  {isFree ? 'Free' : `$${game.price}`}
                </span>
              </div>
            </div>
          </div>

          {/* Glow Effect */}
          <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
            <div className="absolute inset-0 bg-gradient-to-t from-cyan-400/5 to-transparent" />
          </div>
        </motion.div>
      </Link>
    </motion.div>
  );
}
