import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Star } from 'lucide-react';
import type { Game } from '@/types';
import { NeonRing } from './NeonRing';

interface FeaturedGameProps {
  game: Game;
  variant?: 'left' | 'right';
  eyebrow?: string;
}

export function FeaturedGame({ game, variant = 'left', eyebrow }: FeaturedGameProps) {
  const isFree = game.price === 'Free';
  const hasDiscount = game.originalPrice && game.price !== 'Free';
  const displayEyebrow = eyebrow || game.category;

  const isLeft = variant === 'left';

  return (
    <section className="relative w-screen min-h-screen bg-[#0B0C10] overflow-hidden flex items-center">
      {/* Background Neon Ring */}
      <NeonRing 
        className={`${isLeft ? '-right-48' : '-left-48'} top-1/4 opacity-40`}
        size={600}
        duration={30}
      />

      {/* Grain Overlay */}
      <div className="absolute inset-0 grain-overlay" />

      <div className="relative w-full px-6 lg:px-12 py-20">
        <div className={`grid lg:grid-cols-2 gap-12 lg:gap-20 items-center ${isLeft ? '' : 'lg:flex-row-reverse'}`}>
          
          {/* Image Panel */}
          <motion.div
            initial={{ opacity: 0, x: isLeft ? -80 : 80 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className={`relative ${isLeft ? 'lg:order-1' : 'lg:order-2'}`}
          >
            <div className="relative aspect-[3/4] rounded-2xl overflow-hidden panel-shadow">
              <img
                src={game.image}
                alt={game.title}
                className="w-full h-full object-cover"
              />
              
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10]/60 via-transparent to-transparent" />
              
              {/* Border Glow */}
              <div className="absolute inset-0 rounded-2xl border border-white/10" />
            </div>

            {/* Floating Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.5 }}
              className="absolute -bottom-4 -right-4 lg:-right-8"
            >
              <div className="px-4 py-2 bg-cyan-400 text-black font-bold rounded-lg shadow-lg shadow-cyan-400/25">
                {isFree ? 'Free to Play' : `$$${game.price}`}
              </div>
            </motion.div>
          </motion.div>

          {/* Text Content */}
          <motion.div
            initial={{ opacity: 0, x: isLeft ? 80 : -80 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className={`${isLeft ? 'lg:order-2' : 'lg:order-1'}`}
          >
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="mb-4"
            >
              <span className="mono-label text-cyan-400">{displayEyebrow}</span>
            </motion.div>

            {/* Title */}
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="heading-display text-4xl md:text-5xl lg:text-6xl text-white mb-6"
            >
              {game.title.split(' ').map((word, i) => (
                <span key={i} className="block">{word}</span>
              ))}
            </motion.h2>

            {/* Description */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
              className="text-base lg:text-lg text-white/60 leading-relaxed mb-8 max-w-lg"
            >
              {game.description}
            </motion.p>

            {/* Rating & Tags */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap items-center gap-4 mb-8"
            >
              {game.rating && game.rating > 0 && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg">
                  <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  <span className="text-sm font-medium text-white">{game.rating}</span>
                </div>
              )}
              
              {game.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1.5 text-xs font-medium text-white/50 bg-white/5 rounded-lg"
                >
                  {tag}
                </span>
              ))}
            </motion.div>

            {/* Price & CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              className="flex flex-wrap items-center gap-4"
            >
              <Link to={`/game/${game.id}`}>
                <motion.button
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-2 px-6 py-3 bg-cyan-400 text-black font-semibold rounded-lg
                           hover:bg-cyan-300 transition-colors shadow-lg shadow-cyan-400/20"
                >
                  See Details
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </Link>

              <div className="flex items-center gap-3">
                {hasDiscount && (
                  <span className="text-lg text-white/40 line-through">
                    ${game.originalPrice}
                  </span>
                )}
                <span className={`text-2xl font-bold ${isFree ? 'text-green-400' : 'text-white'}`}>
                  {isFree ? 'Free' : `$${game.price}`}
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
