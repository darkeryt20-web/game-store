import { motion } from 'framer-motion';

interface NeonRingProps {
  className?: string;
  size?: number;
  duration?: number;
}

export function NeonRing({ className = '', size = 400, duration = 20 }: NeonRingProps) {
  return (
    <motion.div
      className={`absolute rounded-full pointer-events-none ${className}`}
      style={{
        width: size,
        height: size,
        border: '1px solid rgba(0, 240, 255, 0.15)',
        boxShadow: `
          0 0 60px rgba(0, 240, 255, 0.1),
          inset 0 0 60px rgba(0, 240, 255, 0.05)
        `,
      }}
      animate={{
        rotate: 360,
      }}
      transition={{
        duration,
        repeat: Infinity,
        ease: 'linear',
      }}
    >
      {/* Inner ring */}
      <div
        className="absolute inset-8 rounded-full"
        style={{
          border: '1px solid rgba(0, 240, 255, 0.08)',
        }}
      />
      {/* Outer glow */}
      <div
        className="absolute -inset-4 rounded-full opacity-50"
        style={{
          background: 'radial-gradient(circle, rgba(0, 240, 255, 0.05) 0%, transparent 70%)',
        }}
      />
    </motion.div>
  );
}
