export interface Game {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  price: number | 'Free';
  originalPrice?: number;
  category: GameCategory;
  image: string;
  rating?: number;
  tags: string[];
  releaseDate?: string;
  developer?: string;
  features?: string[];
}

export type GameCategory = 
  | 'Action' 
  | 'Adventure' 
  | 'RPG' 
  | 'Horror' 
  | 'Strategy' 
  | 'Free' 
  | 'Specials' 
  | 'New Release' 
  | 'Top Rated' 
  | 'Upcoming' 
  | 'Latest Release' 
  | 'Most Played' 
  | 'Recommended' 
  | 'Updates';

export interface TeamMember {
  name: string;
  role: string;
  bio: string;
  image?: string;
  socials: {
    twitter?: string;
    github?: string;
    linkedin?: string;
    discord?: string;
  };
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export interface NavItem {
  label: string;
  path: string;
}
