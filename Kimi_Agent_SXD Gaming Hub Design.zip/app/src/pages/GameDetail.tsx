import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Star, 
  Calendar, 
  User, 
  Check, 
  Monitor, 
  Gamepad2, 
  Cloud,
  Trophy,
  Share2,
  Heart,
  ShoppingCart
} from 'lucide-react';
import { games } from '@/data/games';
import { NeonRing } from '@/components/ui-custom/NeonRing';
import { GameCard } from '@/components/ui-custom/GameCard';

// Feature icons mapping
const featureIcons: Record<string, React.ElementType> = {
  'Ray Tracing': Monitor,
  'DLSS Support': Monitor,
  'Controller Support': Gamepad2,
  'Cloud Saves': Cloud,
  '4K Support': Monitor,
  'HDR': Monitor,
  'Achievements': Trophy,
  'Trading Cards': Share2,
  'Cross-Platform': Monitor,
  'VR Support': Monitor,
  'Mod Support': Gamepad2,
  'Dedicated Servers': Cloud,
  'Leaderboards': Trophy,
  'Speedrun Mode': Trophy,
  'Level Editor': Gamepad2,
  'Steam Workshop': Share2,
  '4-Player Co-op': User,
  'Local Co-op': User,
  'Online Co-op': User,
  'PvP Mode': User,
  'Season Pass': Trophy,
  'Battle Royale': User,
  'New Game+': Trophy,
  'DLC Available': ShoppingCart,
  '12v12 Battles': User,
  'Mech Customization': Gamepad2,
  'Ranked Mode': Trophy,
  'Esports Ready': Trophy,
  'Free Updates': Cloud,
  'Cosmetic Shop': ShoppingCart,
  'Guild System': User,
  'Events': Trophy,
  'Full Controller': Gamepad2,
  'Ghost Replays': Monitor,
};

export default function GameDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const game = games.find(g => g.id === id);
  
  // Get related games (same category or tags, excluding current)
  const relatedGames = games
    .filter(g => g.id !== id && (
      g.category === game?.category || 
      g.tags.some(tag => game?.tags.includes(tag))
    ))
    .slice(0, 3);

  if (!game) {
    return (
      <main className="relative bg-[#0B0C10] min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="heading-display text-4xl text-white mb-4">GAME NOT FOUND</h1>
          <p className="text-white/50 mb-8">The game you're looking for doesn't exist.</p>
          <Link to="/">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="px-6 py-3 bg-cyan-400 text-black font-semibold rounded-lg"
            >
              Back to Store
            </motion.button>
          </Link>
        </div>
      </main>
    );
  }

  const isFree = game.price === 'Free';
  const hasDiscount = game.originalPrice && game.price !== 'Free';

  return (
    <main className="relative bg-[#0B0C10] min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img
            src={game.image}
            alt={game.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-[#0B0C10]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0B0C10]/60 to-transparent" />
        </div>

        {/* Neon Ring */}
        <NeonRing className="-right-64 top-1/4 opacity-30" size={600} duration={40} />

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col justify-end">
          <div className="w-full px-6 lg:px-12 py-16">
            {/* Back Button */}
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 text-white/60 hover:text-white transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Store
            </motion.button>

            <div className="max-w-3xl">
              {/* Category Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="mb-4"
              >
                <span className="px-3 py-1 bg-cyan-400/20 border border-cyan-400/30 rounded-md 
                               text-xs font-medium text-cyan-400 uppercase tracking-wider">
                  {game.category}
                </span>
              </motion.div>

              {/* Title */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="heading-display text-5xl md:text-6xl lg:text-7xl text-white mb-6"
              >
                {game.title.toUpperCase()}
              </motion.h1>

              {/* Meta Info */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="flex flex-wrap items-center gap-4 mb-6"
              >
                {game.rating && game.rating > 0 && (
                  <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-lg">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    <span className="text-sm font-medium text-white">{game.rating}</span>
                  </div>
                )}
                
                {game.releaseDate && (
                  <div className="flex items-center gap-2 text-white/50">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">{new Date(game.releaseDate).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</span>
                  </div>
                )}

                {game.developer && (
                  <div className="flex items-center gap-2 text-white/50">
                    <User className="w-4 h-4" />
                    <span className="text-sm">{game.developer}</span>
                  </div>
                )}
              </motion.div>

              {/* Tags */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="flex flex-wrap gap-2 mb-8"
              >
                {game.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 text-xs font-medium text-white/60 bg-white/5 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </motion.div>

              {/* Price & CTA */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex flex-wrap items-center gap-4"
              >
                <motion.button
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-2 px-8 py-4 bg-cyan-400 text-black font-semibold rounded-lg
                           hover:bg-cyan-300 transition-colors shadow-lg shadow-cyan-400/25"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {isFree ? 'Play Free' : 'Get Game'}
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex items-center gap-2 px-6 py-4 bg-white/10 text-white font-semibold rounded-lg
                           border border-white/20 hover:bg-white/15 transition-colors"
                >
                  <Heart className="w-5 h-5" />
                  Wishlist
                </motion.button>

                <div className="flex items-center gap-3 ml-auto">
                  {hasDiscount && (
                    <span className="text-xl text-white/40 line-through">
                      ${game.originalPrice}
                    </span>
                  )}
                  <span className={`text-3xl font-bold ${isFree ? 'text-green-400' : 'text-white'}`}>
                    {isFree ? 'Free' : `$${game.price}`}
                  </span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Details Section */}
      <section className="relative py-20">
        <div className="w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="heading-display text-2xl text-white mb-6">ABOUT THIS GAME</h2>
                <p className="text-lg text-white/60 leading-relaxed mb-8">
                  {game.longDescription || game.description}
                </p>

                {/* Screenshots placeholder */}
                <div className="grid grid-cols-2 gap-4 mb-12">
                  {[1, 2, 3, 4].map((i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0.95 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.1 }}
                      className="aspect-video bg-white/5 rounded-lg border border-white/5 
                               flex items-center justify-center overflow-hidden"
                    >
                      <img
                        src={game.image}
                        alt={`Screenshot ${i}`}
                        className="w-full h-full object-cover opacity-50 hover:opacity-75 transition-opacity"
                      />
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-[#111318] rounded-xl p-6 border border-white/5 sticky top-24"
              >
                <h3 className="text-lg font-bold text-white mb-4">FEATURES</h3>
                
                {game.features && game.features.length > 0 ? (
                  <ul className="space-y-3">
                    {game.features.map((feature, index) => {
                      const Icon = featureIcons[feature] || Check;
                      return (
                        <motion.li
                          key={feature}
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: index * 0.05 }}
                          className="flex items-center gap-3 text-white/60"
                        >
                          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-4 h-4 text-cyan-400" />
                          </div>
                          <span className="text-sm">{feature}</span>
                        </motion.li>
                      );
                    })}
                  </ul>
                ) : (
                  <p className="text-white/40 text-sm">No features listed.</p>
                )}

                {/* System Requirements placeholder */}
                <div className="mt-8 pt-6 border-t border-white/5">
                  <h3 className="text-lg font-bold text-white mb-4">SYSTEM REQUIREMENTS</h3>
                  <div className="space-y-4 text-sm">
                    <div>
                      <span className="text-white/40 block mb-1">Minimum:</span>
                      <span className="text-white/60">Windows 10, Intel i5, 8GB RAM, GTX 1060</span>
                    </div>
                    <div>
                      <span className="text-white/40 block mb-1">Recommended:</span>
                      <span className="text-white/60">Windows 11, Intel i7, 16GB RAM, RTX 3060</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Related Games */}
      {relatedGames.length > 0 && (
        <section className="relative py-20 bg-[#111318]">
          <div className="w-full px-6 lg:px-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="mb-12"
            >
              <h2 className="heading-display text-2xl text-white">YOU MIGHT ALSO LIKE</h2>
            </motion.div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedGames.map((relatedGame, index) => (
                <GameCard key={relatedGame.id} game={relatedGame} index={index} />
              ))}
            </div>
          </div>
        </section>
      )}
    </main>
  );
}
