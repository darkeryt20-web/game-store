import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronLeft, ChevronRight, Filter, Sparkles } from 'lucide-react';
import { games, categories } from '@/data/games';
import { GameCard } from '@/components/ui-custom/GameCard';
import { NeonRing } from '@/components/ui-custom/NeonRing';
import type { Game } from '@/types';

// Hero Slider Component
function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const featuredGames = games.slice(0, 3);
  
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredGames.length);
  };
  
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredGames.length) % featuredGames.length);
  };

  return (
    <section className="relative w-full h-screen bg-[#0B0C10] overflow-hidden">
      {/* Background Images */}
      {featuredGames.map((game, index) => (
        <motion.div
          key={game.id}
          initial={false}
          animate={{
            opacity: currentSlide === index ? 1 : 0,
            scale: currentSlide === index ? 1 : 1.1,
          }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="absolute inset-0"
        >
          <img
            src={game.image}
            alt={game.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0B0C10] via-[#0B0C10]/80 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10] via-transparent to-transparent" />
        </motion.div>
      ))}

      {/* Neon Ring Decoration */}
      <NeonRing className="-right-64 -top-64 opacity-30" size={800} duration={40} />

      {/* Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="w-full px-6 lg:px-12">
          <div className="max-w-2xl">
            {featuredGames.map((game, index) => (
              <motion.div
                key={game.id}
                initial={false}
                animate={{
                  opacity: currentSlide === index ? 1 : 0,
                  y: currentSlide === index ? 0 : 30,
                }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className={`${currentSlide === index ? 'block' : 'hidden'}`}
              >
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="mono-label text-cyan-400 mb-4 block"
                >
                  FEATURED
                </motion.span>
                
                <h1 className="heading-display text-5xl md:text-6xl lg:text-7xl text-white mb-6">
                  {game.title.toUpperCase()}
                </h1>
                
                <p className="text-lg text-white/60 mb-8 max-w-lg">
                  {game.description}
                </p>

                <div className="flex flex-wrap items-center gap-4">
                  <Link to={`/game/${game.id}`}>
                    <motion.button
                      whileHover={{ scale: 1.02, y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      className="flex items-center gap-2 px-8 py-4 bg-cyan-400 text-black font-semibold rounded-lg
                               hover:bg-cyan-300 transition-colors shadow-lg shadow-cyan-400/25"
                    >
                      Browse the Store
                      <ArrowRight className="w-5 h-5" />
                    </motion.button>
                  </Link>
                  
                  <Link to="/about">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className="px-8 py-4 bg-white/10 text-white font-semibold rounded-lg border border-white/20
                               hover:bg-white/15 transition-colors"
                    >
                      View Showcase
                    </motion.button>
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Slide Controls */}
      <div className="absolute bottom-12 left-6 lg:left-12 z-20 flex items-center gap-4">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={prevSlide}
          className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center
                   text-white hover:bg-white/10 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
        </motion.button>
        
        <div className="flex items-center gap-2">
          {featuredGames.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-1 rounded-full transition-all duration-300 ${
                currentSlide === index 
                  ? 'w-8 bg-cyan-400' 
                  : 'w-2 bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={nextSlide}
          className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center
                   text-white hover:bg-white/10 transition-colors"
        >
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>

      {/* Slide Counter */}
      <div className="absolute bottom-12 right-6 lg:right-12 z-20">
        <span className="text-4xl font-bold text-white/20">
          {String(currentSlide + 1).padStart(2, '0')}
        </span>
        <span className="text-lg text-white/40 mx-2">/</span>
        <span className="text-lg text-white/40">
          {String(featuredGames.length).padStart(2, '0')}
        </span>
      </div>
    </section>
  );
}

// Filter Section Component
function FilterSection({ 
  selectedCategory, 
  onCategoryChange 
}: { 
  selectedCategory: string; 
  onCategoryChange: (category: string) => void;
}) {
  return (
    <section className="relative py-8 bg-[#0B0C10] border-y border-white/5">
      <div className="w-full px-6 lg:px-12">
        <div className="flex items-center gap-4 overflow-x-auto pb-2 scrollbar-hide">
          <div className="flex items-center gap-2 text-white/40 mr-4 flex-shrink-0">
            <Filter className="w-4 h-4" />
            <span className="text-sm font-medium">Filter:</span>
          </div>
          
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onCategoryChange(category)}
              className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                selectedCategory === category
                  ? 'bg-cyan-400 text-black'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </div>
      </div>
    </section>
  );
}

// Game Grid Section
function GameGrid({ games: filteredGames }: { games: Game[] }) {
  return (
    <section className="relative py-20 bg-[#0B0C10]">
      {/* Grain Overlay */}
      <div className="absolute inset-0 grain-overlay" />
      
      <div className="relative w-full px-6 lg:px-12">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-center justify-between mb-12"
        >
          <div>
            <span className="mono-label text-cyan-400 mb-2 block">BROWSE</span>
            <h2 className="heading-display text-3xl md:text-4xl text-white">
              ALL GAMES
            </h2>
          </div>
          
          <div className="flex items-center gap-2 text-white/40">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm">{filteredGames.length} games</span>
          </div>
        </motion.div>

        {/* Games Grid */}
        {filteredGames.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredGames.map((game, index) => (
              <GameCard key={game.id} game={game} index={index} />
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <p className="text-white/40 text-lg">No games found in this category.</p>
          </motion.div>
        )}
      </div>
    </section>
  );
}

// Main Home Component
export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredGames = useMemo(() => {
    if (selectedCategory === 'All') return games;
    return games.filter(game => 
      game.category === selectedCategory || 
      game.tags.includes(selectedCategory)
    );
  }, [selectedCategory]);

  return (
    <main className="relative">
      <HeroSlider />
      <FilterSection 
        selectedCategory={selectedCategory} 
        onCategoryChange={setSelectedCategory} 
      />
      <GameGrid games={filteredGames} />
    </main>
  );
}
