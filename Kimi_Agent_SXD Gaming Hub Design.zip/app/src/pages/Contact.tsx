import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MessageCircle, Youtube, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { NeonRing } from '@/components/ui-custom/NeonRing';
import { submitContactForm } from '@/lib/supabase';

// Contact methods
const contactMethods = [
  {
    icon: Phone,
    label: 'Phone',
    value: '+1 (555) 123-4567',
    href: 'tel:+15551234567',
    color: 'from-green-400 to-emerald-500'
  },
  {
    icon: MessageCircle,
    label: 'Discord',
    value: 'discord.gg/sxd',
    href: 'https://discord.gg/sxd',
    color: 'from-indigo-400 to-purple-500'
  },
  {
    icon: Youtube,
    label: 'YouTube',
    value: '@SXDGameCenter',
    href: 'https://youtube.com/sxdgamecenter',
    color: 'from-red-400 to-rose-500'
  },
  {
    icon: Mail,
    label: 'Email',
    value: 'hello@sxdgamecenter.com',
    href: 'mailto:hello@sxdgamecenter.com',
    color: 'from-cyan-400 to-blue-500'
  }
];

// Form state type
interface FormState {
  name: string;
  email: string;
  subject: string;
  message: string;
}

// Form errors type
interface FormErrors {
  name?: string;
  email?: string;
  subject?: string;
  message?: string;
}

export default function Contact() {
  const [formData, setFormData] = useState<FormState>({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!formData.subject.trim()) {
      newErrors.subject = 'Subject is required';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    setSubmitStatus('idle');
    
    try {
      const result = await submitContactForm(formData);
      
      if (result.success) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', subject: '', message: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  return (
    <main className="relative bg-[#0B0C10] min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <NeonRing className="-right-64 top-0 opacity-30" size={600} duration={35} />
        
        {/* Grain Overlay */}
        <div className="absolute inset-0 grain-overlay" />

        <div className="relative w-full px-6 lg:px-12 py-32">
          <div className="max-w-3xl">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mono-label text-cyan-400 mb-4 block"
            >
              GET IN TOUCH
            </motion.span>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="heading-display text-5xl md:text-6xl lg:text-7xl text-white mb-6"
            >
              LET'S BUILD
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                THE NEXT WORLD
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-white/60 leading-relaxed"
            >
              Press, creators, or players—reach out. We read everything and love hearing from our community.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="relative py-16 bg-[#111318]">
        <div className="w-full px-6 lg:px-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {contactMethods.map((method, index) => (
              <motion.a
                key={method.label}
                href={method.href}
                target={method.href.startsWith('http') ? '_blank' : undefined}
                rel={method.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -4 }}
                className="group p-6 bg-white/5 rounded-xl border border-white/5 hover:border-white/10 transition-all"
              >
                <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${method.color} 
                                flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <method.icon className="w-5 h-5 text-white" />
                </div>
                <div className="text-sm text-white/40 mb-1">{method.label}</div>
                <div className="text-white font-medium group-hover:text-cyan-400 transition-colors">
                  {method.value}
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="relative py-24">
        <NeonRing className="-left-48 top-1/2 -translate-y-1/2 opacity-20" size={400} duration={25} />
        
        <div className="relative w-full px-6 lg:px-12">
          <div className="max-w-2xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-[#111318] rounded-2xl p-8 lg:p-12 border border-white/5"
            >
              <div className="text-center mb-8">
                <h2 className="heading-display text-2xl md:text-3xl text-white mb-2">
                  SEND US A MESSAGE
                </h2>
                <p className="text-white/50">
                  Fill out the form below and we'll get back to you as soon as possible.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name & Email Row */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-white/70 mb-2">
                      Your Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-white/30
                                focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all ${
                        errors.name ? 'border-red-400/50' : 'border-white/10'
                      }`}
                      placeholder="John Doe"
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-400">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-white/70 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-white/30
                                focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all ${
                        errors.email ? 'border-red-400/50' : 'border-white/10'
                      }`}
                      placeholder="john@example.com"
                    />
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-400">{errors.email}</p>
                    )}
                  </div>
                </div>

                {/* Subject */}
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-white/70 mb-2">
                    Subject
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className={`w-full px-4 py-3 bg-white/5 border rounded-lg text-white
                              focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all ${
                      errors.subject ? 'border-red-400/50' : 'border-white/10'
                    }`}
                  >
                    <option value="" className="bg-[#111318]">Select a subject</option>
                    <option value="general" className="bg-[#111318]">General Inquiry</option>
                    <option value="support" className="bg-[#111318]">Technical Support</option>
                    <option value="business" className="bg-[#111318]">Business Partnership</option>
                    <option value="press" className="bg-[#111318]">Press & Media</option>
                    <option value="feedback" className="bg-[#111318]">Feedback</option>
                  </select>
                  {errors.subject && (
                    <p className="mt-1 text-sm text-red-400">{errors.subject}</p>
                  )}
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-white/70 mb-2">
                    Your Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    className={`w-full px-4 py-3 bg-white/5 border rounded-lg text-white placeholder-white/30
                              focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all resize-none ${
                      errors.message ? 'border-red-400/50' : 'border-white/10'
                    }`}
                    placeholder="Tell us what's on your mind..."
                  />
                  {errors.message && (
                    <p className="mt-1 text-sm text-red-400">{errors.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <motion.button
                  type="submit"
                  disabled={isSubmitting}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  className="w-full flex items-center justify-center gap-2 px-8 py-4 bg-cyan-400 text-black 
                           font-semibold rounded-lg hover:bg-cyan-300 transition-colors 
                           disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      Send Message
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </motion.button>

                {/* Status Messages */}
                {submitStatus === 'success' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2 p-4 bg-green-400/10 border border-green-400/20 rounded-lg"
                  >
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <p className="text-green-400">Message sent successfully! We'll get back to you soon.</p>
                  </motion.div>
                )}

                {submitStatus === 'error' && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2 p-4 bg-red-400/10 border border-red-400/20 rounded-lg"
                  >
                    <AlertCircle className="w-5 h-5 text-red-400" />
                    <p className="text-red-400">Something went wrong. Please try again later.</p>
                  </motion.div>
                )}
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="relative py-24 bg-[#111318]">
        <div className="w-full px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-center"
          >
            <h2 className="heading-display text-2xl md:text-3xl text-white mb-4">
              THE DROP
            </h2>
            <p className="text-white/50 mb-8">
              Subscribe to our newsletter for releases, updates, and behind-the-scenes notes.
            </p>

            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white 
                         placeholder-white/30 focus:outline-none focus:ring-2 focus:ring-cyan-400/50"
              />
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="px-6 py-3 bg-cyan-400 text-black font-semibold rounded-lg 
                         hover:bg-cyan-300 transition-colors whitespace-nowrap"
              >
                Subscribe
              </motion.button>
            </form>
          </motion.div>
        </div>
      </section>
    </main>
  );
}
