import { motion } from 'framer-motion';
import { Twitter, Github, Linkedin, MessageCircle, Target, Zap, Users, Award } from 'lucide-react';
import { teamMembers } from '@/data/games';
import { NeonRing } from '@/components/ui-custom/NeonRing';

// Stats Section
const stats = [
  { icon: Target, value: '50+', label: 'Games Published' },
  { icon: Users, value: '10M+', label: 'Active Players' },
  { icon: Zap, value: '99.9%', label: 'Uptime' },
  { icon: Award, value: '25+', label: 'Industry Awards' }
];

// Values Section
const values = [
  {
    title: 'Player First',
    description: 'Every decision we make starts with the player experience. We build games we want to play.'
  },
  {
    title: 'Bold Innovation',
    description: 'We push boundaries and challenge conventions. Safe choices rarely create memorable experiences.'
  },
  {
    title: 'Craft Excellence',
    description: 'Quality is non-negotiable. We polish until it shines, then polish some more.'
  },
  {
    title: 'Community Driven',
    description: 'Our players shape our games. We listen, adapt, and grow together with our community.'
  }
];

// Team Member Card
function TeamCard({ member, index }: { member: typeof teamMembers[0]; index: number }) {
  const socialIcons = {
    twitter: Twitter,
    github: Github,
    linkedin: Linkedin,
    discord: MessageCircle
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.6, delay: index * 0.15, ease: [0.22, 1, 0.36, 1] }}
      className="group relative"
    >
      <div className="relative bg-[#111318] rounded-2xl p-8 border border-white/5 
                      hover:border-cyan-400/20 transition-all duration-500">
        {/* Avatar */}
        <div className="relative w-24 h-24 mx-auto mb-6">
          <div className="absolute inset-0 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 opacity-20 blur-xl group-hover:opacity-40 transition-opacity" />
          <div className="relative w-full h-full rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 
                          flex items-center justify-center text-2xl font-bold text-black">
            {member.name.split(' ').map(n => n[0]).join('')}
          </div>
        </div>

        {/* Info */}
        <div className="text-center mb-6">
          <h3 className="text-xl font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors">
            {member.name}
          </h3>
          <p className="text-sm text-cyan-400 mb-3">{member.role}</p>
          <p className="text-sm text-white/50 leading-relaxed">{member.bio}</p>
        </div>

        {/* Social Links */}
        <div className="flex items-center justify-center gap-3">
          {Object.entries(member.socials).map(([platform, url]) => {
            const Icon = socialIcons[platform as keyof typeof socialIcons];
            if (!Icon || !url) return null;
            
            return (
              <motion.a
                key={platform}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center
                         text-white/50 hover:text-cyan-400 hover:border-cyan-400/30 transition-colors"
                aria-label={platform}
              >
                <Icon className="w-4 h-4" />
              </motion.a>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}

// Main About Component
export default function About() {
  return (
    <main className="relative bg-[#0B0C10] min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <NeonRing className="-right-64 top-1/4 opacity-30" size={600} duration={35} />
        <NeonRing className="-left-32 bottom-0 opacity-20" size={400} duration={25} />
        
        {/* Grain Overlay */}
        <div className="absolute inset-0 grain-overlay" />

        <div className="relative w-full px-6 lg:px-12 py-32">
          <div className="max-w-4xl">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mono-label text-cyan-400 mb-4 block"
            >
              ABOUT SXD
            </motion.span>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="heading-display text-5xl md:text-6xl lg:text-7xl text-white mb-8"
            >
              WE BUILD
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                WORLDS
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-white/60 leading-relaxed max-w-2xl"
            >
              SXD Game Center is more than a store—we are a studio, a curator, and a community. 
              We believe in tight mechanics, bold art, and stories that stick with you long after 
              you put down the controller.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-20 bg-[#111318]">
        <div className="w-full px-6 lg:px-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center p-6 bg-white/5 rounded-xl border border-white/5"
              >
                <stat.icon className="w-8 h-8 text-cyan-400 mx-auto mb-4" />
                <div className="text-3xl lg:text-4xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-sm text-white/50">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="relative py-24 overflow-hidden">
        <NeonRing className="right-0 top-1/2 -translate-y-1/2 opacity-20" size={500} duration={30} />
        
        <div className="relative w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="mono-label text-cyan-400 mb-4 block">OUR MISSION</span>
              <h2 className="heading-display text-3xl md:text-4xl lg:text-5xl text-white mb-6">
                PLAY BEYOND
                <span className="block">THE SCREEN</span>
              </h2>
              <p className="text-lg text-white/60 leading-relaxed mb-6">
                We started SXD with a simple belief: games should transport you. Not just entertain, 
                but truly transport you to another world where every decision matters and every 
                moment feels alive.
              </p>
              <p className="text-lg text-white/60 leading-relaxed">
                From our first indie release to our latest AAA partnership, we have never lost sight 
                of what matters—the player. Every game in our store is hand-picked, every feature 
                we build is player-requested, and every update is driven by community feedback.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="aspect-square rounded-2xl overflow-hidden">
                <img
                  src="/images/sxd_brand.jpg"
                  alt="SXD Game Center"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C10]/60 to-transparent" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="relative py-24 bg-[#111318]">
        <div className="w-full px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="mono-label text-cyan-400 mb-4 block">OUR VALUES</span>
            <h2 className="heading-display text-3xl md:text-4xl text-white">
              WHAT DRIVES US
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-6 bg-white/5 rounded-xl border border-white/5 hover:border-cyan-400/20 transition-colors"
              >
                <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
                <p className="text-white/50 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="relative py-24">
        <NeonRing className="-left-48 top-1/2 -translate-y-1/2 opacity-20" size={400} duration={25} />
        
        <div className="relative w-full px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="mono-label text-cyan-400 mb-4 block">THE TEAM</span>
            <h2 className="heading-display text-3xl md:text-4xl text-white">
              MEET THE CREATORS
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {teamMembers.map((member, index) => (
              <TeamCard key={member.name} member={member} index={index} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 bg-[#111318]">
        <div className="w-full px-6 lg:px-12">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-2xl mx-auto"
          >
            <h2 className="heading-display text-3xl md:text-4xl text-white mb-6">
              READY TO JOIN THE JOURNEY?
            </h2>
            <p className="text-lg text-white/60 mb-8">
              Explore our collection of curated games and become part of the SXD community.
            </p>
            <motion.a
              href="/"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-2 px-8 py-4 bg-cyan-400 text-black font-semibold rounded-lg
                       hover:bg-cyan-300 transition-colors shadow-lg shadow-cyan-400/25"
            >
              Browse the Store
            </motion.a>
          </motion.div>
        </div>
      </section>
    </main>
  );
}
