import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface ContactMessage {
  id?: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  created_at?: string;
}

export async function submitContactForm(data: Omit<ContactMessage, 'id' | 'created_at'>) {
  try {
    const { data: result, error } = await supabase
      .from('contact_messages')
      .insert([{ ...data, created_at: new Date().toISOString() }]);

    if (error) {
      console.error('Supabase error:', error);
      throw error;
    }

    return { success: true, data: result };
  } catch (error) {
    console.error('Error submitting contact form:', error);
    return { success: false, error };
  }
}
